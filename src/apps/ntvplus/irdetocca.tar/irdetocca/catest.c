//#include<UniversalClient.h>
#include<UniversalClient_Stdlib.h>
//#include<ngl_types.h>
//#include<ngl_log.h>
//#include<ngl_msgq.h>

NGL_MODULE(MAIN);
int main(){
   char buffer[100];
   UniversalClient_Stdlib_memset(buffer,0,100);
   //extern void UniversalClient_Ini(void);
   //UniversalClient_Init();
   //unsigned int msg[4];
   //msg[0]=0x2100;
   //nglMsgQSend((HANDLE)0x1000,msg,sizeof(msg),100);
   //NGLOG_INFO("Hello world!");
}
