// SPI Version
#include "stdio.h"

#define SPI_lib_ChangeList "SPI lib ChangeList: 1"

void Get_SPI_ChangeList_Info(void)
{
    printf("-------------------------");
    printf("%s \n", SPI_lib_ChangeList);
    printf("-------------------------");
}

